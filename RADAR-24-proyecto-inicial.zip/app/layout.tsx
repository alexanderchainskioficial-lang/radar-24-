import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "RADAR 24 | Centro de información",
  description: "Panel personal de noticias, mercados, clima y geopolítica.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}