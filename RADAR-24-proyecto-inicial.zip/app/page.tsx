"use client";

import { useEffect, useState } from "react";
import {
  Activity, ArrowDownRight, ArrowUpRight, Bell, Bookmark, BriefcaseBusiness,
  ChevronDown, CloudSun, Globe2, LayoutDashboard, Menu, Newspaper, Search,
  ShieldAlert, Sun, TrendingUp, Wallet, X
} from "lucide-react";

const markets = [
  { name: "Dólar oficial", value: "—", change: "Sin conectar", kind: "neutral" },
  { name: "Dólar blue", value: "—", change: "Sin conectar", kind: "neutral" },
  { name: "Dólar MEP", value: "—", change: "Sin conectar", kind: "neutral" },
  { name: "Dólar CCL", value: "—", change: "Sin conectar", kind: "neutral" },
  { name: "Mayorista", value: "—", change: "Sin conectar", kind: "neutral" },
  { name: "Euro", value: "—", change: "Sin conectar", kind: "neutral" },
];

const navItems = [
  { label: "Resumen", icon: LayoutDashboard },
  { label: "Argentina", icon: Newspaper },
  { label: "Mundo", icon: Globe2 },
  { label: "Mercados", icon: TrendingUp },
  { label: "Clima", icon: CloudSun },
  { label: "Geopolítica", icon: ShieldAlert },
];

export default function Home() {
  const [time, setTime] = useState("--:--:--");
  const [date, setDate] = useState("");
  const [active, setActive] = useState("Resumen");
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  useEffect(() => {
    const update = () => {
      const now = new Date();
      setTime(new Intl.DateTimeFormat("es-AR", {
        timeZone: "America/Argentina/Buenos_Aires",
        hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false
      }).format(now));
      setDate(new Intl.DateTimeFormat("es-AR", {
        timeZone: "America/Argentina/Buenos_Aires",
        weekday: "long", day: "2-digit", month: "long", year: "numeric"
      }).format(now));
    };
    update();
    const id = setInterval(update, 1000);
    return () => clearInterval(id);
  }, []);

  const selectNav = (label: string) => {
    setActive(label);
    setMenuOpen(false);
    const target = document.getElementById(label.toLowerCase().replace("í", "i"));
    if (label === "Resumen") window.scrollTo({ top: 0, behavior: "smooth" });
    else target?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <main className="app-shell">
      <aside className={`sidebar ${menuOpen ? "sidebar-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark"><Activity size={22} strokeWidth={2.6} /></div>
          <div><div className="brand-name">RADAR <span>24</span></div><div className="brand-caption">CENTRO DE INFORMACIÓN</div></div>
          <button className="close-menu" onClick={() => setMenuOpen(false)} aria-label="Cerrar menú"><X size={19}/></button>
        </div>
        <div className="nav-label">ESPACIO DE TRABAJO</div>
        <nav className="nav-list">
          {navItems.map(({label, icon: Icon}) => (
            <button key={label} className={`nav-item ${active === label ? "active" : ""}`} onClick={() => selectNav(label)}>
              <Icon size={18} /><span>{label}</span>{label === "Resumen" && <span className="nav-dot" />}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="status-card">
            <div className="status-top"><span className="status-indicator" /> PANEL INICIAL</div>
            <p>Tu centro de información está listo para conectar fuentes.</p>
            <span className="status-tag">CONFIGURACIÓN PENDIENTE</span>
          </div>
          <div className="profile">
            <div className="profile-avatar">R</div>
            <div className="profile-text"><strong>Mi RADAR</strong><span>Panel personal</span></div>
            <ChevronDown size={16} className="muted-icon"/>
          </div>
        </div>
      </aside>

      {menuOpen && <button className="mobile-scrim" onClick={() => setMenuOpen(false)} aria-label="Cerrar menú" />}

      <section className="main-area">
        <header className="topbar">
          <div className="topbar-left">
            <button className="mobile-menu" onClick={() => setMenuOpen(true)} aria-label="Abrir menú"><Menu size={21}/></button>
            <div className="breadcrumb">Espacio de trabajo <span>/</span> <strong>{active}</strong></div>
          </div>
          <div className="topbar-right">
            <div className="clock"><span className="clock-dot"/><strong>{time}</strong><span className="clock-zone">ART</span></div>
            <button className="icon-button" aria-label="Buscar" onClick={() => setSearchOpen(!searchOpen)}><Search size={18}/></button>
            <button className="icon-button notification" aria-label="Notificaciones"><Bell size={18}/><i/></button>
          </div>
        </header>

        {searchOpen && <div className="search-panel"><Search size={17}/><input autoFocus placeholder="Buscar noticias, temas o mercados…" /><button onClick={() => setSearchOpen(false)}><X size={17}/></button></div>}

        <div className="content">
          <section className="welcome-row">
            <div>
              <div className="eyebrow"><span className="eyebrow-line"/> TU CENTRO DE INTELIGENCIA</div>
              <h1>Buen día. Este es tu <span>RADAR.</span></h1>
              <p className="welcome-sub">Una mirada clara a lo que importa, en un solo lugar.</p>
              <div className="date-line"><Sun size={15}/><span className="capitalize">{date}</span><span className="date-separator">·</span><span>Buenos Aires, Argentina</span></div>
            </div>
            <div className="live-pill"><span className="live-dot"/> PANEL ACTIVO</div>
          </section>

          <section className="market-section" id="mercados">
            <div className="section-heading">
              <div><div className="section-kicker">EN UN VISTAZO</div><h2>Mercados y cotizaciones</h2></div>
              <span className="updated-label"><span className="gray-dot"/> Esperando fuentes de datos</span>
            </div>
            <div className="market-grid">
              {markets.map((item, i) => (
                <article className="market-card" key={item.name}>
                  <div className="market-card-top"><span className="market-name">{item.name}</span><span className="market-icon">{i < 4 ? <Wallet size={15}/> : <TrendingUp size={15}/>}</span></div>
                  <div className="market-value">{item.value}</div>
                  <div className="market-change"><span className="neutral-pill">{item.change}</span></div>
                </article>
              ))}
            </div>
            <div className="source-note"><ShieldAlert size={14}/> Las cotizaciones no están conectadas todavía. No se muestran valores estimados ni inventados.</div>
          </section>

          <section className="feature-grid">
            <article className="panel flash-panel" id="argentina">
              <div className="panel-heading">
                <div className="panel-icon flash-icon"><Activity size={17}/></div>
                <div><div className="section-kicker">LO MÁS IMPORTANTE</div><h2>FLASH 10</h2></div>
                <span className="count-badge">0 / 10</span>
              </div>
              <div className="empty-state">
                <div className="empty-illustration"><Newspaper size={24}/></div>
                <h3>Las noticias aparecerán aquí</h3>
                <p>Este espacio reunirá las 10 noticias principales, ordenadas por relevancia y sin duplicados.</p>
                <span className="pending-label"><span className="gray-dot"/> Fuentes pendientes de conectar</span>
              </div>
              <div className="panel-footer"><span>Selección editorial</span><span>Actualización automática: pendiente</span></div>
            </article>

            <article className="panel weather-panel" id="clima">
              <div className="panel-heading">
                <div className="panel-icon weather-icon"><CloudSun size={18}/></div>
                <div><div className="section-kicker">BUENOS AIRES</div><h2>Clima y alertas</h2></div>
                <span className="outline-badge">SMN</span>
              </div>
              <div className="weather-empty">
                <div className="weather-art"><CloudSun size={36} strokeWidth={1.4}/></div>
                <div><div className="weather-temp">—° <span> C</span></div><div className="weather-description">Datos meteorológicos pendientes</div></div>
              </div>
              <div className="weather-details">
                <div><span>Temperatura</span><strong>—</strong></div><div><span>Humedad</span><strong>—</strong></div><div><span>Viento</span><strong>—</strong></div>
              </div>
              <div className="panel-footer"><span>Fuente prevista: Servicio Meteorológico Nacional</span><span>Sin datos</span></div>
            </article>
          </section>

          <section className="lower-grid">
            <article className="panel news-panel" id="mundo">
              <div className="panel-heading">
                <div className="panel-icon world-icon"><Globe2 size={17}/></div>
                <div><div className="section-kicker">CONTEXTO GLOBAL</div><h2>Argentina y el mundo</h2></div>
                <button className="text-action" onClick={() => selectNav("Mundo")}>Ver secciones <ArrowUpRight size={14}/></button>
              </div>
              <div className="category-row">
                {["Política", "Economía", "Empresas", "Energía", "EE. UU.", "Europa", "China y Asia", "Medio Oriente"].map(x => <button key={x} className="category-chip">{x}</button>)}
              </div>
              <div className="compact-empty"><div className="compact-empty-icon"><BriefcaseBusiness size={18}/></div><div><strong>Información verificada, sin ruido.</strong><p>Las noticias se mostrarán con fecha, medio de origen y enlace a la publicación.</p></div></div>
            </article>

            <article className="panel geo-panel" id="geopolitica">
              <div className="panel-heading">
                <div className="panel-icon geo-icon"><ShieldAlert size={17}/></div>
                <div><div className="section-kicker">LECTURA ESTRATÉGICA</div><h2>Radar geopolítico</h2></div>
              </div>
              <div className="geo-content">
                <div className="geo-line"><span className="geo-number">01</span><div><strong>Hechos confirmados</strong><p>Qué ocurrió y qué fuentes lo respaldan.</p></div></div>
                <div className="geo-line"><span className="geo-number">02</span><div><strong>Interpretaciones</strong><p>Qué podría significar, separado de los hechos.</p></div></div>
                <div className="geo-line"><span className="geo-number">03</span><div><strong>Escenarios posibles</strong><p>Riesgos, señales a observar y nivel de confianza.</p></div></div>
              </div>
              <div className="panel-footer"><span>Marco de análisis</span><span>Contenido pendiente</span></div>
            </article>
          </section>

          <section className="briefing-panel" id="resumen">
            <div className="briefing-icon"><Bookmark size={18}/></div>
            <div className="briefing-copy"><div className="section-kicker">RESUMEN EJECUTIVO</div><h2>El día en 5 minutos</h2><p>Un resumen breve de los acontecimientos clave, su impacto y qué conviene seguir durante el día.</p></div>
            <div className="briefing-status"><span className="gray-dot"/> Se habilitará al conectar fuentes</div>
          </section>

          <footer className="footer"><div><span className="footer-brand">RADAR 24</span><span>Información para entender mejor el día.</span></div><div><span className="footer-dot"/> <span>Prototipo inicial</span><span className="footer-sep">·</span><span>Zona horaria ART</span></div></footer>
        </div>
      </section>
    </main>
  );
}