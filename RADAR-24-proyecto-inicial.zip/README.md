# RADAR 24

Dashboard personal de noticias, mercados, clima y geopolítica, en español y con zona horaria de Buenos Aires.

## Qué incluye esta primera versión

- Interfaz adaptable a celular y computadora.
- Navegación por secciones.
- Reloj en zona horaria `America/Argentina/Buenos_Aires`.
- Tarjetas para cotizaciones, FLASH 10, clima, noticias y análisis geopolítico.
- Estados vacíos explícitos para no inventar cotizaciones, clima ni noticias.

## Importante

Esta es la **interfaz inicial**. Todavía no está conectada a fuentes de noticias, cotizaciones o clima. Los valores aparecen como `—` hasta implementar y configurar las integraciones de datos.

## Ejecutar en computadora

Necesitás Node.js 18.17 o posterior.

```bash
npm install
npm run dev
```

Después abrí `http://localhost:3000`.

## Publicar

Podés importar el repositorio desde Vercel una vez que el proyecto esté subido a GitHub. No hay claves privadas ni archivos `.env` incluidos en este ZIP.
